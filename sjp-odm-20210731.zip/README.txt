
Słownik SJP.PL - wersja: odmiany słów

Słownik udostępniany na licencjach GPL 2, LGPL 2.1,
Apache 2.0 oraz Creative Commons Attribution 4.0 International

https://sjp.pl

